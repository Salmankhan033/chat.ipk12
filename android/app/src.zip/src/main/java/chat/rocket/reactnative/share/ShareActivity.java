package chat.rocket.reactnative.share;

import com.facebook.react.ReactActivity;

public class ShareActivity extends ReactActivity {
    @Override
    protected String getMainComponentName() {
        return "ShareRocketChatRN";
    }
}