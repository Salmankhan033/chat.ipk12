package chat.rocket.reactnative;

import android.os.Bundle;

import androidx.annotation.Nullable;

public class Callback {
    public void call(@Nullable Bundle bundle) {

    }
}
